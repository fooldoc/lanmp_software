#!/bin/sh
# Copyright (C) 2016 and later: Unicode, Inc. and others.
# License & terms of use: http://www.unicode.org/copyright.html
#  /* Copyright (C) 2011-2012 IBM Corporation and Others. All Rights Reserved */
icc -o iculd iculd.c
icc -o cxxfilt cxxfilt.cpp


